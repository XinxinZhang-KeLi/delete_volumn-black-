# -*- coding:utf-8 -*-
import xlwt
import xlrd


class Handle_excel(object):

    # def __init__(self):
    def creat_excel(self, sheet_name):
        file = xlwt.Workbook(encoding='utf-8', style_compression=0)
        sheet = file.add_sheet(sheet_name)
        return file, sheet

    def write_excel(self, a, b, c):
        sheet.write(a, b, c)

    def save_excel(slef, excel_name):
        file.save(excel_name)

    def tableTOJson(self, i, file_path):
        worksheet = xlrd.open_workbook(file_path)
        sheet_names = worksheet.sheet_names()  # 获取所有工作表名
        sheet1 = worksheet.sheet_by_name(sheet_names[0])
        cols = sheet1.col_values(0)
        return cols[i]

    def Num_content(self, file_name):
        worksheet = xlrd.open_workbook(file_name)
        sheet_names = worksheet.sheet_names()  # 获取所有工作表名
        sheet1 = worksheet.sheet_by_name(sheet_names[0])
        cols = sheet1.col_values(0)
        return len(cols)

    def Improve_excel(self, file_path):
        N = self.Num_content(file_path)
        k = 0
        # i = 0
        contents = []
        while k < N:
            content = self.tableTOJson(k, file_path)
            # print(len(content))
            if len(content) != 0:
                contents.append(content)
            k += 1
        for i in range(len(contents)):
            self.write_excel(i, 0, contents[i])
        return "Have been done!"


object = Handle_excel()
b = input("请输入转后的sheet的名字：")
a = input("请输入转换后的excel的名字：")
file_path = input("请输入你要转化的excel文件所在目录：")
file, sheet = object.creat_excel(b)
response = object.Improve_excel(file_path)
print(response)
object.save_excel(a + '.xls')
