# -*- coding:utf-8 -*-
# author-zhangxinxin
import os

import xlrd
import xlwt


class Handle_excel(object):

    def creat_excel(self, sheet_name):
        file = xlwt.Workbook(encoding='utf-8', style_compression=0)
        sheet = file.add_sheet(sheet_name)
        return file, sheet

    def write_excel(self, sheet, a, b, c):
        sheet.write(a, b, c)

    def Num_row(self, file_path):
        worksheet = xlrd.open_workbook(file_path)
        sheet_names = worksheet.sheet_names()
        sheet1 = worksheet.sheet_by_name(sheet_names[0])
        cols = sheet1.col_values(0)
        return len(cols)

    def save_excel(slef, file, excel_name):
        file.save(excel_name)

    def tableTOJson(self, k, num1, file_path):
        worksheet = xlrd.open_workbook(file_path)
        sheet_names = worksheet.sheet_names()  # 获取所有工作表名
        sheet1 = worksheet.sheet_by_name(sheet_names[0])
        # num2 = input('请输入你的excel里面的列数：')
        rows2 = []
        for i in range(int(num1)):
            rows = sheet1.row_values(i)
            for row in rows:
                if len(str(row).strip()) == 0:
                    rows = []
            if len(rows) != 0:
                rows2.append(rows)
        print(rows2[k])
        return rows2[k]

        # return cols[i]

    def Num_content(self, num1, file_name):
        worksheet = xlrd.open_workbook(file_name)
        sheet_names = worksheet.sheet_names()  # 获取所有工作表名
        print(sheet_names[0])
        sheet1 = worksheet.sheet_by_name(sheet_names[0])
        # num2 = input('请输入你的excel里面的列数：')
        rows2 = []
        for i in range(int(num1)):
            rows = sheet1.row_values(i)
            for row in rows:
                if len(str(row).strip()) == 0:
                    rows = []
            if len(rows) != 0:
                # print(len(rows[0].strip()))
                rows2.append(rows)
        return len(rows2)

    def Improve_excel(self, sheet, num1, file_path):
        N = self.Num_content(num1, file_path)
        print(N)  # 打印出来看看转换后有多少页
        k = 0
        i = 0
        # j = 0
        while k < N:
            contents = self.tableTOJson(k, num1, file_path)
            j = 0
            for content in contents:
                self.write_excel(sheet, i, j, content)
                j += 1
            i += 1
            k += 1
        return "Have been done!"

    def Sheet_name(self, file_name):
        worksheet = xlrd.open_workbook(file_name)
        sheet_names = worksheet.sheet_names()  # 获取所有工作表名
        # sheet1 = worksheet.sheet_by_name(sheet_names[0])
        return sheet_names[0]


# def P_handle(Sumfile_path):

def Start(file_path):
    object = Handle_excel()
    # b = 'xxxx'
    b = object.Sheet_name(file_path)
    # a = input("请输入转换后的excel的名字：")
    # a = 'YYYYYYYYYYYxxxx'
    # num1 = input('请输入你的excel里面的行数：')
    # file_path = 'F:\\untitled\excel文件格式处理（去除空格）\dfb.xls'
    num1 = object.Num_row(file_path)
    file, sheet = object.creat_excel(b)
    response = object.Improve_excel(sheet, num1, file_path)
    print(response)
    object.save_excel(file, file_path.split('.')[0] + '-转.xlsx')


def P_handle(Sum_file_path):
    for a in os.walk(Sum_file_path):
        # print(a[2])
        for excel_name in a[2]:
            print(excel_name)
            Start(Sum_file_path + '\\' + excel_name)


P_handle('需要处理的文件')
